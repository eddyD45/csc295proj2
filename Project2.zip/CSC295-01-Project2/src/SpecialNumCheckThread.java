
public class SpecialNumCheckThread extends Thread{
	
	private SpecialNumbers[] specialNumbers;
	private int start;
	private int end;
	public static int validCount;
	public static SpecialNumbers someInstance;
	private int indivCount;
	private int variance;
	private boolean validFound = false;
	
	
	
	
	public SpecialNumCheckThread(SpecialNumbers[] specialNumbers, int start, int end) {
		super();
		this.specialNumbers = specialNumbers;
		this.start = start;
		this.end = end;
	}
	
	public void run() {
		int count = 0;
		for(int i = start; i <=end; i++) {
			SpecialNumbers temp = specialNumbers[i];
			if(!isPrime(temp.getNonPrimeNum()) && isPrime(temp.getPrimeNum()) && isPerfect(temp.getPerfectNum())) {
				incValidCount();
				count++;
				if(!validFound) {
					setInstance(temp);
					validFound = true;
				}
			}
		}
		indivCount = count;
	}
	
	public int getValidCount() {
		return indivCount;
	}
	
	public int getVariance() {
		return variance;
	}

	public boolean isPrime(int n) {
		for(int i = 2; i < Math.sqrt(n); i++) {
			if(n % i == 0) {
				return false;
			}
		}
		return true;
	}
	
	public boolean isPerfect(int n) {
		if(!(n <=500)) {
			return false;
		}
		return true;
		
	}
	
	synchronized public void incValidCount() {
		validCount++;;
	}
	
	synchronized public void setInstance(SpecialNumbers specialNumber) {
		someInstance = specialNumber;
	}

}
