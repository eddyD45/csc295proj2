package loadbalanced;

import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * A class to represent the task of finding the number in a given range of
 * integers that has the largest number of divisors. The range is specified in
 * the constructor. The task is executed when the compute() method is called. At
 * the end of the compute() method, a Result object is created to represent the
 * results from this task, and the result object is added to resultQueue.
 */
public class Task {
	int min, max; // Start and end of the range of integers for this task.
	SpecialNumbers[] specialNumbers;
	LinkedBlockingQueue<Result> resultQueue;

	Task(int min, int max, SpecialNumbers[] specialNumbers, LinkedBlockingQueue<Result> resultQueue) {
		this.min = min;
		this.max = max;
		this.specialNumbers = specialNumbers;
		this.resultQueue = resultQueue;
	}

	public void compute() {
		int count = 0;
		double lowestVariance = calculateVariance(specialNumbers[min].getNonPrimeNum(), specialNumbers[min].getPrimeNum(), specialNumbers[min].getPerfectNum());
		int whichIndex = 0;
		ArrayList<Integer> validIndexes = new ArrayList<Integer>();
		for (int i = min; i < max; i++) {
			SpecialNumbers temp = specialNumbers[i];
			if(calculateVariance(temp.getNonPrimeNum(), temp.getPrimeNum(), temp.getPerfectNum()) < lowestVariance) {
				
				lowestVariance = calculateVariance(temp.getNonPrimeNum(), temp.getPrimeNum(), temp.getPerfectNum());
				whichIndex = i;
//				if (!isPrime(temp.getNonPrimeNum()) && isPrime(temp.getPrimeNum()) && isPerfect(temp.getPerfectNum())) {
//					count++;
//					whichIndex = i;
//				}
//				
			}
		}
		System.out.println("Lowest variance at: " + whichIndex);
		
		for(int i = min; i < max; i++) {
			SpecialNumbers temp = specialNumbers[i];
			if(calculateVariance(temp.getNonPrimeNum(), temp.getPrimeNum(), temp.getPerfectNum()) == lowestVariance) {
				validIndexes.add(i);
			}
		}
		
		if(validIndexes.size() > 0) {
			for(int i = 0; i < validIndexes.size(); i++) {
				SpecialNumbers temp = specialNumbers[validIndexes.get(i)];
				if (!isPrime(temp.getNonPrimeNum()) && isPrime(temp.getPrimeNum()) && isPerfect(temp.getPerfectNum())) {
					count++;
					whichIndex = validIndexes.get(i);
					System.out.println("Lowest variance that meets the three criteria at: " + whichIndex);
				}
				
			}
		}
			
		
		resultQueue.add(new Result(count, whichIndex));
	}

	public boolean isPrime(int n) {
		for(int i = 2; i < Math.sqrt(n); i++) {
			if(n % i == 0) {
				return false;
			}
		}
		return true;
	}
	
	public boolean isPerfect(int n) {
		if(!(n <=500)) {
			return false;
		}
		return true;
		
	}
	
	public double calculateVariance(int nonPrime, int prime, int perfect) {
		double avg = (nonPrime + prime + perfect) / 3;
		double first = Math.pow(nonPrime - avg,2);
		double second = Math.pow(prime - avg,2);
		double third = Math.pow(perfect - avg,2);
		
		return (first + second + third) / 2;
	}
}
