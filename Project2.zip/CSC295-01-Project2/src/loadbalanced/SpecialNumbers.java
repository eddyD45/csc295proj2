package loadbalanced;

public class SpecialNumbers {

	private int nonPrimeNum;
	private int primeNum;
	private int perfectNum;
	
	
	
	public SpecialNumbers() {
		super();
		nonPrimeNum = generateRandomNum();
		primeNum = generateRandomNum();
		perfectNum = generateRandomNum();
	}
	
	

	public int getNonPrimeNum() {
		return nonPrimeNum;
	}



	public int getPrimeNum() {
		return primeNum;
	}



	public int getPerfectNum() {
		return perfectNum;
	}



//	public int generatePerfectNum( ) {
//		int probability = (int)(Math.random() * 10) + 1;
//		
//		if(probability <= 3) {
//			return (int)(Math.random() * 50) + 1;
//		}
//		if(probability > 3 && probability <=8) {
//			return (int) (Math.random() * (450 - 50)) + 51;
//		}
//		return (int) (Math.random() * (500 - 450)) + 451;
//		
//	}
	
	public int generateRandomNum() {
		return (int) (Math.random() * (10000)) + 1;
	}

	@Override
	public String toString() {
		return "SpecialNumbers [nonPrimeNum=" + nonPrimeNum + ", primeNum=" + primeNum + ", perfectNum=" + perfectNum
				+ "]";
	}
	
	
}
