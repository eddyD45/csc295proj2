package loadbalanced;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Tester {

	public static void main(String[] args) throws InterruptedException {

		int MAX = 10000;
		int SPLIT = 500;
		long startTime = System.nanoTime();

		ConcurrentLinkedQueue<Task> taskQueue = new ConcurrentLinkedQueue<Task>();

		LinkedBlockingQueue<Result> resultQueue = new LinkedBlockingQueue<Result>();

		int numberOfThreads = 4;
		SpecialNumbers[] specialNumbers = new SpecialNumbers[MAX];
		
		for(int i = 0; i < specialNumbers.length; i++) {
			specialNumbers[i] = new SpecialNumbers();
		}

		int numberOfTasks = MAX / SPLIT;
		for (int i = 0; i < numberOfTasks; i++) {
			int start = i * SPLIT;
			int end = (i + 1) * SPLIT - 1;
			taskQueue.add(new Task(start, end, specialNumbers,resultQueue));
		}

		SpecialNumCheckerThread[] workers = new SpecialNumCheckerThread[numberOfThreads];
		for (int i = 0; i < workers.length; i++)
			workers[i] = new SpecialNumCheckerThread(taskQueue);

		for (int i = 0; i < numberOfThreads; i++)
			workers[i].start();

		/*
		 * The threads will execute the tasks and results will be placed into
		 * the result queue. This method now goes on to read all the results
		 * from the result queue and combine them to give the overall answer.
		 */
		int count = 0;
		int index = 0;
		for (int i = 0; i < numberOfTasks; i++) {
			Result result = resultQueue.take();
//			if (result.getMaxDivisorFromTask() > maxDivisorCount) {
//				maxDivisorCount = result.getMaxDivisorFromTask();
//				intWithMaxDivisorCount = result.getIntWithMaxFromTask();
//			}
			count += result.getCountFromTask();
			index = result.getIndexFromTask();

		}
		/* Report the results. */

		long elapsedTime = System.nanoTime() - startTime;
		System.out.println("There are " + count + " valid Special Numbers from a pool of " + MAX + " Special Numbers.");
		if(count > 0) {
			System.out.println("An instance of such a valid object looks like: " + specialNumbers[index]);
		}
		System.out.println("Calcualted using " + numberOfThreads + " threads running " + numberOfTasks + " tasks.");
		System.out.println("Run time: " + elapsedTime + "ns");
		System.out.println("Change result so it passes its lowest variance, pass to tester and calculate the lowest of the lowest there.");
	}

}
