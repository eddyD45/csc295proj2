package loadbalanced;

import java.util.concurrent.ConcurrentLinkedQueue;

public class SpecialNumCheckerThread extends Thread {

	private ConcurrentLinkedQueue<Task> taskQueue;

	public SpecialNumCheckerThread(ConcurrentLinkedQueue<Task> taskQueue) {
		this.taskQueue = taskQueue;
	}

	public void run() {
		while (true) {
			Task task = taskQueue.poll();
			if (task == null)
				break;
			task.compute();
		}
	}
}