package loadbalanced;

public class Result {
	private int countFromTask;
	private int indexFromTask;

	public Result(int countFromTask, int indexFromTask) {
		super();
		this.countFromTask = countFromTask;
		this.indexFromTask = indexFromTask;
	}

	public int getCountFromTask() {
		return countFromTask;
	}

	public void setCountFromTask(int countFromTask) {
		this.countFromTask = countFromTask;
	}

	public int getIndexFromTask() {
		return indexFromTask;
	}

	public void setIndexFromTask(int indexFromTask) {
		this.indexFromTask = indexFromTask;
	}

	
	
}