import java.util.ArrayList;

public class Tester {

	public static void main(String[] args) throws InterruptedException {
		long startTime = System.currentTimeMillis();
		int MAX = 10000;
		int numberofThreads = 4;
		SpecialNumbers [] specialNumbers = new SpecialNumbers[MAX];
		int interval = (MAX/numberofThreads);
		int start = 0;
		int end = interval - 1;;
		
		for(int i = 0; i < specialNumbers.length; i++) {
			specialNumbers[i] = new SpecialNumbers();
		}
		
		SpecialNumCheckThread [] checkers = new SpecialNumCheckThread[numberofThreads];
		
		for(int i = 0; i < checkers.length; i++) {
			checkers[i] = new SpecialNumCheckThread(specialNumbers, start, end);
			start = end + 1;
			if(i == numberofThreads - 2) {
				end = MAX-1;
			}
			else {
				end += interval;
			}
		}
		
		for(int i = 0; i < checkers.length; i++) {
			checkers[i].start();
		}
		for(int i = 0; i < checkers.length; i++) {
			checkers[i].join();
		}

		System.out.println("Total valid count: " + SpecialNumCheckThread.validCount);
		System.out.println("Some instance of a valid object looks like: " + SpecialNumCheckThread.someInstance);
		System.out.println("Run time: " + (System.currentTimeMillis() - startTime) + "ms");

	}
}
